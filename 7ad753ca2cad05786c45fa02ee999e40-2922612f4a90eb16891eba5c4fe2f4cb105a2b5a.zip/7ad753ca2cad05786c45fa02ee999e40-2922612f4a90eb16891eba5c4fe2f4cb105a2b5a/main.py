import pyttsx3

engine = pyttsx3.init()
while True:
    user = input("Enter a number (or type 'quit' to exit): ")
    if user == 'quit':
        break
    def speak(text):
        engine.say(text)
        engine.runAndWait()
    speak(user)

